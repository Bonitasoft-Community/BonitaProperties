

package org.bonitasoft.bonitaproperties.rest;

import groovy.json.JsonBuilder

import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

import org.apache.http.HttpHeaders
import org.bonitasoft.ext.properties.BonitaProperties;
import org.bonitasoft.ext.properties.AccessProperties;
import org.bonitasoft.ext.properties.AccessProperties.Rule;
import org.bonitasoft.ext.properties.AccessProperties.RulesResult;
import org.bonitasoft.log.event.BEvent;
import org.bonitasoft.log.event.BEventFactory;
import org.bonitasoft.web.extension.ResourceProvider
import org.bonitasoft.web.extension.rest.RestApiResponse
import org.bonitasoft.web.extension.rest.RestApiResponseBuilder
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.json.simple.JSONValue;

import com.bonitasoft.web.extension.rest.RestAPIContext
import com.bonitasoft.web.extension.rest.RestApiController

import org.bonitasoft.ext.properties.BonitaProperties;

class AdminBonitaAccessPutProperties implements RestApiController {

	private static final Logger logger = LoggerFactory.getLogger(GetBonitaProperties.class)

	@Override
	RestApiResponse doHandle(HttpServletRequest request, RestApiResponseBuilder responseBuilder, RestAPIContext context) {
		// To retrieve query parameters use the request.getParameter(..) method.
		// Be careful, parameter values are always returned as String values

		// expect :
		//  - action=initialize 	: check and create the database
		//  - action=readall 		: read all in the properties

		// Retrieve domain parameter
		Rule rule = new Rule();
		rule.name= request.getParameter "name";
		rule.domain= request.getParameter "domain";
		rule.ruleName= request.getParameter "ruleName";

		String isReadOnly = request.getParameter "readOnly";
		rule.isReadOnly= "TRUE".equalsIgnoreCase( isReadOnly);

		String domainIsUserId = request.getParameter "domainIsUserId";
		rule.domainIsUserId= "TRUE".equalsIgnoreCase( domainIsUserId );

		String isAdmin = request.getParameter "isAdmin";
		rule.isAdmin= "TRUE".equalsIgnoreCase( isAdmin );

		String applyAllDomain = request.getParameter "applyAllDomain";
		rule.applyAllDomain= "TRUE".equalsIgnoreCase( applyAllDomain );

		rule.profileName = request.getParameter "profileName";
		rule.roleName = request.getParameter "roleName";
		rule.groupPath = request.getParameter "groupPath";
		rule.userName = request.getParameter "userName";

		String clean = request.getParameter("clean");
		Map result = new HashMap<String,String>();
		
		if ("true".equalsIgnoreCase(clean))
		{
			if (rule.name == null || rule.name.trim().length()==0)
				return buildResponse(responseBuilder, HttpServletResponse.SC_BAD_REQUEST,"""{"error" : "Clean : give a name """+rule.name+"""}""");
			AccessProperties accessProperties = new AccessProperties();
			RulesResult ruleResult = accessProperties.getRules();

			List<Rule> listNewRules = new ArrayList<Rule>();
			for (int i=0;i<ruleResult.listRules.size();i++)
			{
				if (! rule.name.equalsIgnoreCase(ruleResult.listRules.get( i ).name))
					listNewRules.add( ruleResult.listRules.get( i ) );
				else
					logger.info("AdminBonitaAccessPutProperties ****** Delete rule["+ ruleResult.listRules.get( i ).ruleName+"] due to name["+rule.name+"]");
				
			}
			logger.info("AdminBonitaAccessPutProperties Keep["+listNewRules.size()+"]rule");
			
			ruleResult.listEvents.addAll( accessProperties.setRules( listNewRules ));
			
			result.put("message",ruleResult.listRules.size() - listNewRules.size()+" rules deleted with name["+rule.name+"]");
			result.put("status", BEventFactory.isError( ruleResult.listEvents)? "ERROR" : "OK");
			result.put("listevents", BEventFactory.getHtml( ruleResult.listEvents));
			
		}
		else
		{

			logger.info("AdminBonitaAccessPutProperties rule=["+rule.toString()+"] isValid ? "+rule.isValid());
			// Retrieve name parameter
			if (! rule.isValid() == null) {
				return buildResponse(responseBuilder, HttpServletResponse.SC_BAD_REQUEST,"""{"error" : "Rule is not acceptable : """+rule.getError()+"""}""")
			}

			AccessProperties accessProperties = new AccessProperties();
			RulesResult ruleResult = accessProperties.getRules();
			if (! BEventFactory.isError(ruleResult.listEvents)) {
				// if a rule with the same name exist ? Then replace it
				boolean addTheRule=true;
				if (rule.ruleName!=null && rule.ruleName.trim().length()>0)
				{
					logger.info("AdminBonitaAccessPutProperties rule=["+rule.ruleName.toString()+"] exist? ");
					rule.ruleName=rule.ruleName.trim();
					for (int i=0;i<ruleResult.listRules.size();i++)
					{
						//logger.info("AdminBonitaAccessPutProperties Compare with=["+ruleResult.listRules.get( i ).toString()+"]");
						//logger.info("AdminBonitaAccessPutProperties Compare ["+rule.ruleName+"] <> ["+ruleResult.listRules.get( i ).ruleName+"]");

						if (rule.ruleName.equalsIgnoreCase(ruleResult.listRules.get( i ).ruleName))
						{
							//logger.info("AdminBonitaAccessPutProperties Same name, overwrite it");
							ruleResult.listRules.set( i, rule);
							addTheRule=false;
						}
					}
				}
				//logger.info("AdminBonitaAccessPutProperties Add the rule");
				if (addTheRule)
					ruleResult.listRules.add( rule );
				//logger.info("AdminBonitaAccessPutProperties Save rules");
				ruleResult.listEvents.addAll( accessProperties.setRules(  ruleResult.listRules ));
			}
			result.put("listevents", BEventFactory.getHtml(ruleResult.listEvents));
			result.put("status", BEventFactory.isError(ruleResult.listEvents)? "ERROR" : "OK");
		}

		logger.info("AdminBonitaAccessPutProperties calcul result");

		logger.info("AdminBonitaAccessPutProperties:result  return="+result);

		// Send the result as a JSON representation
		// You may use buildPagedResponse if your result is multiple
		return buildResponse(responseBuilder, HttpServletResponse.SC_OK, new JsonBuilder(result).toPrettyString())
	}

	/**
	 * Build an HTTP response.
	 *
	 * @param  responseBuilder the Rest API response builder
	 * @param  httpStatus the status of the response
	 * @param  body the response body
	 * @return a RestAPIResponse
	 */
	RestApiResponse buildResponse(RestApiResponseBuilder responseBuilder, int httpStatus, Serializable body) {
		return responseBuilder.with {
			withResponseStatus(httpStatus)
			withResponse(body)
			build()
		}
	}

	/**
	 * Returns a paged result like Bonita BPM REST APIs.
	 * Build a response with content-range data in the HTTP header.
	 *
	 * @param  responseBuilder the Rest API response builder
	 * @param  body the response body
	 * @param  p the page index
	 * @param  c the number of result per page
	 * @param  total the total number of results
	 * @return a RestAPIResponse
	 */
	RestApiResponse buildPagedResponse(RestApiResponseBuilder responseBuilder, Serializable body, int p, int c, long total) {
		return responseBuilder.with {
			withAdditionalHeader(HttpHeaders.CONTENT_RANGE,"$p-$c/$total");
			withResponse(body)
			build()
		}
	}

}
