

package org.bonitasoft.bonitaproperties.rest;
	
import groovy.json.JsonBuilder
	
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

import org.apache.http.HttpHeaders
import org.bonitasoft.ext.properties.BonitaProperties;
import org.bonitasoft.log.event.BEvent;
import org.bonitasoft.log.event.BEventFactory;
import org.bonitasoft.web.extension.ResourceProvider
import org.bonitasoft.web.extension.rest.RestApiResponse
import org.bonitasoft.web.extension.rest.RestApiResponseBuilder
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.json.simple.JSONValue;

import com.bonitasoft.web.extension.rest.RestAPIContext
import com.bonitasoft.web.extension.rest.RestApiController

import org.bonitasoft.ext.properties.BonitaProperties;
import org.bonitasoft.ext.properties.AccessProperties;
import org.bonitasoft.ext.properties.AccessProperties.Rule;
import org.bonitasoft.ext.properties.AccessProperties.RulesResult;


class AdminBonitaAccessGetProperties implements RestApiController {

	private static final Logger logger = LoggerFactory.getLogger(AdminBonitaAccessGetProperties.class)
	
		@Override
		RestApiResponse doHandle(HttpServletRequest request, RestApiResponseBuilder responseBuilder, RestAPIContext context) {
			// To retrieve query parameters use the request.getParameter(..) method.
			// Be careful, parameter values are always returned as String values
	
			// expect :
			//  - action=initialize 	: check and create the database
			//  - action=readall 		: read all in the properties
			
			// Retrieve domain parameter
			
			AccessProperties accessProperties = new AccessProperties();
			RulesResult ruleResult = accessProperties.getRules();

			String filterName= request.getParameter("filtername");
			if (filterName!=null && filterName.trim().length()==0)
				filterName=null;

			Map result = new HashMap<String,String>();
			result.put("listevents", BEventFactory.getHtml(ruleResult.listEvents));
			List<Map<String,Object>> listMapRules = new ArrayList<Map,String,Object>();
			
			// order the result
			Collections.sort(ruleResult.listRules, new Comparator<Rule>()
				{
				  public int compare(Rule r1,
									 Rule r2)
				  {

					return r1.getKeyToOrder().compareTo(r2.getKeyToOrder());
				  }
				});
			for (Rule rule : ruleResult.listRules)
			{
				logger.info("AdminBonitaAccessPutProperties:result  rule="+rule.getKeyToOrder());
				if (filterName!=null && ! filterName.equalsIgnoreCase( rule.name ))
					continue;
				listMapRules.add( rule.toMap());
			}
			
			
			
			result.put("rules", listMapRules);
			result.put("status", BEventFactory.isError(ruleResult.listEvents)? "ERROR" : "OK");
			logger.info("AdminBonitaAccessPutProperties:result  return="+result);
		
        // Send the result as a JSON representation
        // You may use buildPagedResponse if your result is multiple
        return buildResponse(responseBuilder, HttpServletResponse.SC_OK, new JsonBuilder(result).toPrettyString())
    }

    /**
				 * Build an HTTP response.
				 *
				 * @param  responseBuilder the Rest API response builder
				 * @param  httpStatus the status of the response
				 * @param  body the response body
				 * @return a RestAPIResponse
				 */
    RestApiResponse buildResponse(RestApiResponseBuilder responseBuilder, int httpStatus, Serializable body) {
        return responseBuilder.with {
            withResponseStatus(httpStatus)
            withResponse(body)
            build()
        }
    }

    /**
				 * Returns a paged result like Bonita BPM REST APIs.
				 * Build a response with content-range data in the HTTP header.
				 *
				 * @param  responseBuilder the Rest API response builder
				 * @param  body the response body
				 * @param  p the page index
				 * @param  c the number of result per page
				 * @param  total the total number of results
				 * @return a RestAPIResponse
				 */
    RestApiResponse buildPagedResponse(RestApiResponseBuilder responseBuilder, Serializable body, int p, int c, long total) {
        return responseBuilder.with {
            withAdditionalHeader(HttpHeaders.CONTENT_RANGE,"$p-$c/$total");
            withResponse(body)
            build()
        }
    }
		
}
