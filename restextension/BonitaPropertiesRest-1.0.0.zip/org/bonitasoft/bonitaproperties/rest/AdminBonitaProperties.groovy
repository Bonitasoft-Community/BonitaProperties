package org.bonitasoft.bonitaproperties.rest;

import groovy.json.JsonBuilder

import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse
import javax.swing.text.DefaultEditorKit.BeepAction;

import org.apache.http.HttpHeaders
import org.bonitasoft.ext.properties.BonitaProperties;
import org.bonitasoft.log.event.BEvent;
import org.bonitasoft.log.event.BEventFactory;
import org.bonitasoft.web.extension.ResourceProvider
import org.bonitasoft.web.extension.rest.RestApiResponse
import org.bonitasoft.web.extension.rest.RestApiResponseBuilder
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import com.bonitasoft.web.extension.rest.RestAPIContext
import com.bonitasoft.web.extension.rest.RestApiController

/**
 * this properties is for the Administrator, to initialize the properties mechanism, and see the different properties
 *
 */
class AdminBonitaProperties implements RestApiController {

	private static final Logger logger = LoggerFactory.getLogger(GetBonitaProperties.class)

	@Override
	RestApiResponse doHandle(HttpServletRequest request, RestApiResponseBuilder responseBuilder, RestAPIContext context) {
		// To retrieve query parameters use the request.getParameter(..) method.
		// Be careful, parameter values are always returned as String values

		// expect : 
		//  - action=initialize 	: check and create the database
		//  - action=readall 		: read all in the properties
		
		// Retrieve domain parameter
		def action = request.getParameter "action"

		logger.info("AdminBonitaProperties action=["+action+"]");
        // Retrieve name parameter
        if (action == null) {
				return buildResponse(responseBuilder, HttpServletResponse.SC_BAD_REQUEST,"""{"error" : "the parameter action is missing"}""")
			}
			
		Map result = new HashMap<String,String>();
		
		BonitaProperties bonitaProperties = BonitaProperties.getAdminInstance();
		if (action == "initialize")
		{
			logger.info("AdminBonitaProperties:result Initialise");
			List<BEvent> listEvents = bonitaProperties.checkDatabase();
			result.put("listevents", BEventFactory.getHtml(listEvents));
			result.put("status", BEventFactory.isError(listEvents)? "ERROR" : "OK");
		}
		else if (action == "readall")
		{
			def name = request.getParameter( "name" );
			def domain = request.getParameter("domain");
			def keephierarchySt = request.getParameter("hierarchy");
			boolean keephierarchy = Boolean.valueOf(keephierarchySt == null ? false : keephierarchySt);
			
			
			logger.info("AdminBonitaProperties:result readall name=["+name+"] domain=["+domain+"] keephierarchy["+keephierarchy+"]");
			List<BEvent> listEvents = bonitaProperties.load();
			result.put("listevents", BEventFactory.getHtml(listEvents));
			result.put("status", BEventFactory.isError(listEvents)? "ERROR" : "OK");
			Hashtable properties = bonitaProperties.getAllProperties();
			if (name==null || name=="")
				result.put("values", properties);
			else if (domain==null || domain=="")
			{
				logger.info("AdminBonitaProperties:result  name=["+name+"] properties=["+properties.get(name)+"]");
				
				// ---------------- Name Filter level
				if (keephierarchy)
				{
					Map<String,Object> mapName= new HashMap<String,Object>();
					mapName.put(name, properties.get(name));
					result.put("values", mapName);
				}
				else
					result.put("values", properties.get(name));
			}
			else
			{
				// ------------ Domain Filter level
				if (properties.get(name)==null)
					result.put("values", null);

				else 
				{
					if (keephierarchy)
					{
						Map<String,Object> mapName= new HashMap<String,Object>();
						Map<String,Object> mapDomain= new HashMap<String,Object>();
						mapName.put(name, mapDomain);
						mapDomain.put(domain, properties.get(name).get(domain));
						result.put("values",mapName);
					}
					else
						result.put("values", properties.get(name).get(domain));
				}
			}			
		}
		else if (action == "names")
		{
				
			logger.info("AdminBonitaProperties:result readall");
			List<BEvent> listEvents = bonitaProperties.load();
			result.put("listevents", BEventFactory.getHtml(listEvents));
			result.put("status", BEventFactory.isError(listEvents)? "ERROR" : "OK");
			List<String> listNames= new ArrayList<String>();
			for (String key : bonitaProperties.getAllProperties().keySet())
				listNames.add( key )
			result.put("names", );

		}
		else
		{
			result.put("status", "Unknow action use action=initialize or action=readall");
		}

		logger.info("AdminBonitaProperties:result action=["+action+"] return="+result);
		
        // Send the result as a JSON representation
        // You may use buildPagedResponse if your result is multiple
        return buildResponse(responseBuilder, HttpServletResponse.SC_OK, new JsonBuilder(result).toPrettyString())
    }

    /**
			 * Build an HTTP response.
			 *
			 * @param  responseBuilder the Rest API response builder
			 * @param  httpStatus the status of the response
			 * @param  body the response body
			 * @return a RestAPIResponse
			 */
    RestApiResponse buildResponse(RestApiResponseBuilder responseBuilder, int httpStatus, Serializable body) {
        return responseBuilder.with {
            withResponseStatus(httpStatus)
            withResponse(body)
            build()
        }
    }

    /**
			 * Returns a paged result like Bonita BPM REST APIs.
			 * Build a response with content-range data in the HTTP header.
			 *
			 * @param  responseBuilder the Rest API response builder
			 * @param  body the response body
			 * @param  p the page index
			 * @param  c the number of result per page
			 * @param  total the total number of results
			 * @return a RestAPIResponse
			 */
    RestApiResponse buildPagedResponse(RestApiResponseBuilder responseBuilder, Serializable body, int p, int c, long total) {
        return responseBuilder.with {
            withAdditionalHeader(HttpHeaders.CONTENT_RANGE,"$p-$c/$total");
            withResponse(body)
            build()
        }
    }
		}
		
   
