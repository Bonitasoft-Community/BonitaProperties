package org.bonitasoft.bonitaproperties.rest;

import groovy.json.JsonBuilder

import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

import org.apache.http.HttpHeaders
import org.bonitasoft.engine.api.APIClient;
import org.bonitasoft.web.extension.ResourceProvider
import org.bonitasoft.web.extension.rest.RestApiResponse
import org.bonitasoft.web.extension.rest.RestApiResponseBuilder
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import com.bonitasoft.web.extension.rest.RestAPIContext
import com.bonitasoft.web.extension.rest.RestApiController


import org.bonitasoft.log.event.BEvent;
import org.bonitasoft.log.event.BEventFactory;
import org.bonitasoft.ext.properties.BonitaProperties;
import org.bonitasoft.ext.properties.AccessProperties;

class GetBonitaProperties implements RestApiController {

    private static final Logger logger = LoggerFactory.getLogger(GetBonitaProperties.class)

    @Override
    RestApiResponse doHandle(HttpServletRequest request, RestApiResponseBuilder responseBuilder, RestAPIContext context) {
        // To retrieve query parameters use the request.getParameter(..) method.
        // Be careful, parameter values are always returned as String values

		logger.info("GetBonitaProperties: start");
		
        // Retrieve domain parameter
        String name = request.getParameter "name"
        if (name == null) {
				name="REST";
        }
        String domain = request.getParameter "domain"
        if (domain != null && domain.trim().length()==0) 
			domain=null
        

        // Retrieve name parameter
        String key = request.getParameter "key"
        if (key!=null && key.trim().length()==0)
			key=null;

		Map result = new HashMap<String,String>();
			
		AccessProperties accessProperties = new AccessProperties();
		APIClient apiClient = context.getApiClient();
		if (!  accessProperties.isAccepted(name, domain, false,	context.getApiSession(),apiClient.getProcessAPI(),apiClient.getIdentityAPI(),apiClient.getProfileAPI()))
		{
			logger.info("GetBonitaProperties: ACCESS NOT GRANTED, REJECTED");
			
			result.put("error", "No access : check rules");
			return buildResponse(responseBuilder, HttpServletResponse.SC_OK, new JsonBuilder(result).toPrettyString())
		}

		logger.info("GetBonitaProperties: access GRANTED");
		
	
		BonitaProperties bonitaProperties = new BonitaProperties(name);
		bonitaProperties.setCheckDatabase( false );

		List<BEvent> listEvents;
		if (domain==null)
			listEvents = bonitaProperties.load();
		else
			listEvents = bonitaProperties.loaddomainName( domain );
		
		if (BEventFactory.isError(listEvents))
        {
			result.put("error", "Check log server");
        }
		else
		{
			for (String keyprops : bonitaProperties.propertyNames())
			{
				if (key!=null && ! key.equals(keyprops))
					continue;
				result.put(keyprops, bonitaProperties.getProperty( keyprops ))
			}
		}

        // Send the result as a JSON representation
        // You may use buildPagedResponse if your result is multiple
        return buildResponse(responseBuilder, HttpServletResponse.SC_OK, new JsonBuilder(result).toPrettyString())
    }

    /**
     * Build an HTTP response.
     *
     * @param  responseBuilder the Rest API response builder
     * @param  httpStatus the status of the response
     * @param  body the response body
     * @return a RestAPIResponse
     */
    RestApiResponse buildResponse(RestApiResponseBuilder responseBuilder, int httpStatus, Serializable body) {
        return responseBuilder.with {
            withResponseStatus(httpStatus)
            withResponse(body)
            build()
        }
    }

    /**
     * Returns a paged result like Bonita BPM REST APIs.
     * Build a response with content-range data in the HTTP header.
     *
     * @param  responseBuilder the Rest API response builder
     * @param  body the response body
     * @param  p the page index
     * @param  c the number of result per page
     * @param  total the total number of results
     * @return a RestAPIResponse
     */
    RestApiResponse buildPagedResponse(RestApiResponseBuilder responseBuilder, Serializable body, int p, int c, long total) {
        return responseBuilder.with {
            withAdditionalHeader(HttpHeaders.CONTENT_RANGE,"$p-$c/$total");
            withResponse(body)
            build()
        }
    }

    /**
     * Load a property file into a java.util.Properties
     */
    Properties loadProperties(String fileName, ResourceProvider resourceProvider) {
        Properties props = new Properties()
        resourceProvider.getResourceAsStream(fileName).withStream { InputStream s ->
            props.load s
        }
        props
    }

}
